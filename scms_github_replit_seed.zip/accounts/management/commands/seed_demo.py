from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone
from announcements.models import Announcement
from timetable.models import Course, ClassSession, Enrollment

User = get_user_model()

class Command(BaseCommand):
    help = "Seeds demo users, courses, sessions, enrollments, announcements."

    def handle(self, *args, **kwargs):
        staff, _ = User.objects.get_or_create(
            username="staff",
            defaults={"email": "staff@scms.local", "role": "STAFF"}
        )
        staff.set_password("Passw0rd!"); staff.save()

        student, _ = User.objects.get_or_create(
            username="student",
            defaults={"email": "student@scms.local", "role": "STUDENT"}
        )
        student.set_password("Passw0rd!"); student.save()

        cs101, _ = Course.objects.get_or_create(code="CS101", defaults={"title": "Intro to Computing"})
        cs102, _ = Course.objects.get_or_create(code="CS102", defaults={"title": "Software Design"})

        from datetime import time
        ClassSession.objects.get_or_create(course=cs101, lecturer=staff, room="B201",
                                           day_of_week=0, start_time=time(9,0), end_time=time(10,0))
        ClassSession.objects.get_or_create(course=cs101, lecturer=staff, room="B201",
                                           day_of_week=2, start_time=time(9,0), end_time=time(10,0))
        ClassSession.objects.get_or_create(course=cs102, lecturer=staff, room="C105",
                                           day_of_week=1, start_time=time(11,0), end_time=time(12,0))
        ClassSession.objects.get_or_create(course=cs102, lecturer=staff, room="C105",
                                           day_of_week=3, start_time=time(11,0), end_time=time(12,0))

        Enrollment.objects.get_or_create(student=student, course=cs101)
        Enrollment.objects.get_or_create(student=student, course=cs102)

        Announcement.objects.get_or_create(
            title="Welcome to SCMS",
            body="This is a demo announcement for all users.",
            audience="ALL",
            created_by=staff,
            defaults={"expires_at": timezone.now() + timezone.timedelta(days=14)},
        )
        Announcement.objects.get_or_create(
            title="Staff Meeting",
            body="Weekly staff sync on Friday 2pm.",
            audience="STAFF",
            created_by=staff,
            defaults={"expires_at": timezone.now() + timezone.timedelta(days=7)},
        )

        self.stdout.write(self.style.SUCCESS("✅ Demo data seeded."))
        self.stdout.write("Logins:
  Staff: staff / Passw0rd!
  Student: student / Passw0rd!")
