from django.db import models
from django.conf import settings

class Feedback(models.Model):
    CATEGORIES = [("Timetable","Timetable"),("Facility","Facility"),("Other","Other")]
    STATUS = [("OPEN","Open"),("REVIEWED","Reviewed")]
    submitted_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    category = models.CharField(max_length=50, choices=CATEGORIES)
    message = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS, default="OPEN")
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.category} - {self.status}"
