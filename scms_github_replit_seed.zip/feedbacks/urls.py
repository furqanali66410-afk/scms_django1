from django.urls import path
from . import views
urlpatterns = [path('submit/', views.submit_feedback, name='fb_submit'), path('', views.list_feedback, name='fb_list'), path('<int:pk>/reviewed/', views.mark_reviewed, name='fb_reviewed'),]
