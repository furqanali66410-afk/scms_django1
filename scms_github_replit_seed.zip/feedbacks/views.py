from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render, redirect, get_object_or_404
from .models import Feedback
from .forms import FeedbackForm

def is_staff_role(u):
    return u.is_authenticated and u.role == "STAFF"

@login_required
def submit_feedback(request):
    if request.method == "POST":
        form = FeedbackForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.submitted_by = request.user
            obj.save()
            return redirect("dashboard")
    else:
        form = FeedbackForm()
    return render(request, "feedbacks/submit.html", {"form": form})

@login_required
@user_passes_test(is_staff_role)
def list_feedback(request):
    items = Feedback.objects.order_by("-created_at")
    return render(request, "feedbacks/list.html", {"items": items})

@login_required
@user_passes_test(is_staff_role)
def mark_reviewed(request, pk):
    fb = get_object_or_404(Feedback, pk=pk)
    fb.status = "REVIEWED"
    fb.save()
    return redirect("fb_list")
