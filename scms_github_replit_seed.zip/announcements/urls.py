from django.urls import path
from . import views
urlpatterns = [path('', views.ann_list, name='ann_list'), path('new/', views.ann_create, name='ann_create'),]
