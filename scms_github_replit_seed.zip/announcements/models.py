from django.db import models
from django.conf import settings
from django.utils import timezone

class Announcement(models.Model):
    AUDIENCES = [("ALL","All"),("STUDENT","Student"),("STAFF","Staff")]
    title = models.CharField(max_length=200)
    body = models.TextField()
    audience = models.CharField(max_length=20, choices=AUDIENCES, default="ALL")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)

    def is_active(self):
        return self.expires_at is None or self.expires_at > timezone.now()

    def __str__(self):
        return self.title
