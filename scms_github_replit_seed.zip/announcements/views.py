from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render, redirect
from django.db.models import Q
from django.utils.timezone import now
from .models import Announcement
from .forms import AnnouncementForm

def is_staff_role(u):
    return u.is_authenticated and u.role == "STAFF"

@login_required
def ann_list(request):
    qs = Announcement.objects.all().order_by("-created_at")
    if request.user.role == "STUDENT":
        qs = qs.exclude(audience="STAFF")
    qs = qs.filter(Q(expires_at__isnull=True) | Q(expires_at__gt=now()))
    return render(request, "announcements/list.html", {"items": qs})

@login_required
@user_passes_test(is_staff_role)
def ann_create(request):
    if request.method == "POST":
        form = AnnouncementForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.created_by = request.user
            obj.save()
            return redirect("ann_list")
    else:
        form = AnnouncementForm()
    return render(request, "announcements/create.html", {"form": form})
