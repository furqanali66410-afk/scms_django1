from django.contrib import admin
from .models import Course, ClassSession, Enrollment
admin.site.register(Course)
admin.site.register(ClassSession)
admin.site.register(Enrollment)
