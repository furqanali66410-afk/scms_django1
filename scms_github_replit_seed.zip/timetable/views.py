from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render, redirect
from .models import Course, ClassSession, Enrollment
from .forms import ClassSessionForm

def is_staff_role(u):
    return u.is_authenticated and u.role == "STAFF"

@login_required
def my_timetable(request):
    if request.user.role == "STUDENT":
        course_ids = Enrollment.objects.filter(student=request.user).values_list("course_id", flat=True)
        sessions = ClassSession.objects.filter(course_id__in=course_ids).order_by("day_of_week","start_time")
    else:
        sessions = ClassSession.objects.filter(lecturer=request.user).order_by("day_of_week","start_time")
    return render(request, "timetable/my.html", {"sessions": sessions})

@login_required
@user_passes_test(is_staff_role)
def manage_sessions(request):
    sessions = ClassSession.objects.all().order_by("day_of_week","start_time")
    if request.method == "POST":
        form = ClassSessionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("sess_manage")
    else:
        form = ClassSessionForm()
    return render(request, "timetable/manage.html", {"sessions": sessions, "form": form})
