from django import forms
from .models import ClassSession

class ClassSessionForm(forms.ModelForm):
    class Meta:
        model = ClassSession
        fields = ['course','lecturer','room','day_of_week','start_time','end_time']
