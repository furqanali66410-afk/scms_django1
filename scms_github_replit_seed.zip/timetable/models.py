from django.db import models
from django.conf import settings

class Course(models.Model):
    code = models.CharField(max_length=20, unique=True)
    title = models.CharField(max_length=200)
    def __str__(self):
        return f"{self.code} - {self.title}"

class ClassSession(models.Model):
    DAYS = [(i, d) for i, d in enumerate(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"])]
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    lecturer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="lectures")
    room = models.CharField(max_length=50)
    day_of_week = models.IntegerField(choices=DAYS)
    start_time = models.TimeField()
    end_time = models.TimeField()
    def __str__(self):
        return f"{self.course.code} {self.get_day_of_week_display()} {self.start_time}-{self.end_time}"

class Enrollment(models.Model):
    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    class Meta:
        unique_together = ("student", "course")
