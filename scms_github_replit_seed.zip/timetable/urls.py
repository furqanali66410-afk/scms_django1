from django.urls import path
from . import views
urlpatterns = [path('my/', views.my_timetable, name='my_timetable'), path('manage/', views.manage_sessions, name='sess_manage'),]
