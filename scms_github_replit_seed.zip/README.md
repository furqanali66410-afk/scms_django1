# Smart Campus Management System (SCMS) — Django
Ready-to-push GitHub repo with Replit config and demo data seeding.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```
Open http://127.0.0.1:8000

Logins:
- Staff: `staff` / `Passw0rd!`
- Student: `student` / `Passw0rd!`

## Run on Replit
1) Import this repo into Replit (Create Repl → Import from GitHub).
2) Replit auto uses `.replit` to run the server.
3) First time only (open Shell):
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
```
4) Click "Open in a new tab".
```

## Features
- Custom User with roles (Student/Staff)
- Announcements (list/create)
- Timetable (student "My Timetable", staff "Manage Sessions")
- Feedback (student submit, staff review)

## Project Layout
- apps: `accounts`, `announcements`, `timetable`, `feedbacks`
- templates under `templates/`
- seed command: `python manage.py seed_demo`

## License
Educational use.
